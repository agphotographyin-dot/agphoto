const posts = [];
const images = [
  'assets/uploads/01.jpeg',
  'assets/uploads/02.jpeg',
  'assets/uploads/03.jpeg',
  'assets/uploads/04.jpeg',
  'assets/uploads/05.jpeg',
  'assets/uploads/06.jpeg',
  'assets/uploads/07.jpeg',
  'assets/uploads/08.jpeg',
  'assets/uploads/09.jpeg',
  'assets/uploads/010.jpeg',
  'assets/uploads/011.jpeg',
  'assets/uploads/012.jpeg',
  'assets/uploads/013.jpeg',
  'assets/uploads/014.jpeg',
  'assets/uploads/015.jpeg',
  'assets/uploads/016.jpeg',
  'assets/uploads/017.jpeg',
  'assets/uploads/018.jpeg',
  'assets/uploads/019.jpeg',
  'assets/uploads/020.jpeg',
  'assets/uploads/021.jpeg',
  'assets/uploads/022.jpeg',
  'assets/uploads/023.jpeg',
  'assets/uploads/024.jpeg',
  'assets/uploads/025.jpeg',
  'assets/uploads/026.jpeg',
  'assets/uploads/027.jpeg',
  'assets/uploads/028.jpeg',
  'assets/uploads/029.jpeg',
  'assets/uploads/030.jpeg',
  'assets/uploads/031.jpeg',
  'assets/uploads/032.jpeg',
  'assets/uploads/033.jpeg',
  'assets/uploads/034.jpeg',
  'assets/uploads/035.jpeg',
  'assets/uploads/036.jpeg',
  'assets/uploads/037.jpeg',
  'assets/uploads/038.jpeg',
  'assets/uploads/039.jpeg',
  'assets/uploads/040.jpeg',
  'assets/uploads/041.jpeg',
  'assets/uploads/042.jpeg',
  'assets/uploads/043.jpeg',
  'assets/uploads/044.jpeg',
  'assets/uploads/045.jpeg',
  'assets/uploads/046.jpeg',
  'assets/uploads/047.jpeg',
];

let imageIndex = 0;

for (let i = 1; i <= 80; i++) {
  let item = {
    id: i,
    title: `  ${i}`,
    image: images[imageIndex]
    ,
  };
  posts.push(item);
  imageIndex++;
  if (imageIndex > images.length - 1) imageIndex = 0;
}
